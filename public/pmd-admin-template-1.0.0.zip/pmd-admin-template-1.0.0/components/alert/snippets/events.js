<script>
$('#myAlert').on('closed.bs.alert', function () {
  // do something…
})
</script>